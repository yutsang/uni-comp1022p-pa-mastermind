import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class NaughtyGuy extends SpecialCharacter
{
    public void cheat()
    {
		//part 2: complete the code below
		
        
    }
    
    public void superCheat()
    {
		//part 2: complete the code below
		
        
    }
}
