import greenfoot.*;  
import java.util.Random;
import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

public class MastermindWorld extends GWorld
{
    //the dimensions of the game board
    public static final int WORLD_WIDTH = 7;
    public static final int WORLD_HEIGHT = 8;
    public static final int NUMBER_OF_PLAY_ROWS = WORLD_HEIGHT - 1;

    //the constants that represent different objects (or nothing) that present on the game board
    public static final char NOTHING = 'x';
    public static final char BLOCK = 'b';
    public static final char JUDGE = 'j';
    public static final char NICE_JUDGE = 'n';
    public static final char FRIEND_JUDGE = 'f';
    public static final char NAUGHTY_GUY = 'c';
    public static final char WOMBAT = 'w';
    public static final char DOLPHIN = 'd';
    public static final char ELEPHANT = 'e';
    public static final char PIG = 'p';
    public static final char YELLOW_BALLOON = 'y';
    public static final char ORANGE_BALLOON = 'o';

    //the secret, which should be randomized by you at the beginning
    public static String secret = "wde";

    public static int highScore[] = {0, 0, 0}; //you may use this in part 2, or you can ignore it and use your own variables

    static 
    {      
        GWorld.setWidth(WORLD_WIDTH);   
        GWorld.setHeight(WORLD_HEIGHT);
        GWorld.setCellSize(80);
    }

    public MastermindWorld() throws Exception
    {           
        initialize(); 
        generateSecret(); //you may comment out this line temporarily to keep the secret "wde" for testing purpose
    }

    public static void initialize()
    {  
        removeAllObjects();
        
        //part 1: complete the code below
        
    }

    public static void generateSecret()
    {  
        //part 1: complete the code below
        
        
    }

    public static void clearBalloons(int row)
    {  
        //part 1: complete the code below
        
    }

    public static void clearAllBalloons()
    {  
        //part 1: complete the code below
        
    }
    
    public static int calculateRowScore(int row)
    {
        //part 2: complete the code below
        
        
        return 0; //replace this...
    }

    public static int calculateMaxScore()
    {
        //part 2: complete the code below
        

        return 0; //replace this...
    }
    
    public static void showScore()
    {
        //part 2: complete the code below
        
        
    }

    public static void saveGame() throws Exception
    {
        //part 2: complete the code below
        
        
    }

    public static void loadGame() throws Exception
    {
        //part 2: complete the code below
         
        
    } 

    public static void updateHighscores() throws Exception
    {
        //part 2 optional: complete the code below
        
        
    }

    /*
     * Parameters:
     * lowerBound - the (inclusive) lower bound of the random number
     * upperBound - the (inclusive) upper bound of the random number
     * 
     * Example:
     * getRandomNumber(1, 10) will return you a random number that is in range of [1, 10] (including 1 and 10).
     */
    public static int getRandomNumber(int lowerBound, int upperBound)
    {
        Random randomNumberGenerator = new Random();
        return lowerBound + randomNumberGenerator.nextInt(upperBound - lowerBound + 1);
    }

    /*
     * Parameters:
     * objectChar - a character that represents the object that you want to add; you are suggested to use the constants defined in this class, e.g., MastermindWorld.JUDGE
     * x - the x coordinate of the object to be placed (the top-left corner of the world is (0, 0)
     * y - the y coordinate
     * 
     * Example:
     * MastermindWorld.addObject(MastermindWorld.NICE_JUDGE, 2, 3); 
     * will create and place a NiceJudge object to the location (2,3) in the world
     */
    public static void addObject(char objectChar, int x, int y)
    {
        //create the object base on the objectChar
        Actor object = null;
        switch(objectChar)
        {
            case MastermindWorld.JUDGE: 
            object = new Judge();
            break;
            case MastermindWorld.NICE_JUDGE: 
            object = new NiceJudge();
            break;
            case MastermindWorld.FRIEND_JUDGE: 
            object = new FriendJudge();
            break;
            case MastermindWorld.NAUGHTY_GUY: 
            object = new NaughtyGuy();
            break;
            case MastermindWorld.WOMBAT: 
            object = new Wombat();
            break;
            case MastermindWorld.DOLPHIN: 
            object = new Dolphin();
            break;
            case MastermindWorld.ELEPHANT: 
            object = new Elephant();
            break;
            case MastermindWorld.PIG: 
            object = new Pig();
            break;
            case MastermindWorld.YELLOW_BALLOON: 
            object = new YellowBalloon();
            break;
            case MastermindWorld.ORANGE_BALLOON: 
            object = new OrangeBalloon();
            break;
            case MastermindWorld.BLOCK: 
            object = new Block();
            break;
            default:
            return; //just exit the method if nothing should be added

        }   
        GWorld.addOneObject(object, x, y); //add the object to the world
    }

    /*
     * Parameters:
     * x - the x coordinate of the location that you want to check
     * y - the y coordinate
     * 
     * Example:
     * MastermindWorld.getObjectChar(2, 3) will return a character that represents the object that is located at the location (2,3) in the world.
     * If there is a DOLPHIN object there at location (2,3), then the character MastermindWorld.DOLPHIN (which is defined as 'd') will be returned.
     * 
     * If there is nothing at the location, then the character MastermindWorld.NOTHING (which is defined as 'x') will be returned.
     * 
     * We assume that there is always at most one object at each location, except for the case of a Judge/NaughtyGuy sitting on a Block. 
     * For such case, only the Judge/NaughtyGuy will be returned as the result.
     */
    public static char getObjectChar(int x, int y)
    {
        //return the character that represents the object at (x, y)
        if(GWorld.getOneObjectAt(x, y, "NiceJudge") != null) return MastermindWorld.NICE_JUDGE;
        else if(GWorld.getOneObjectAt(x, y, "FriendJudge") != null) return MastermindWorld.FRIEND_JUDGE;
        else if(GWorld.getOneObjectAt(x, y, "Judge") != null) return MastermindWorld.JUDGE;
        else if(GWorld.getOneObjectAt(x, y, "NaughtyGuy") != null) return MastermindWorld.NAUGHTY_GUY;
        else if(GWorld.getOneObjectAt(x, y, "Wombat") != null) return MastermindWorld.WOMBAT;
        else if(GWorld.getOneObjectAt(x, y, "Dolphin") != null) return MastermindWorld.DOLPHIN;
        else if(GWorld.getOneObjectAt(x, y, "Elephant") != null) return MastermindWorld.ELEPHANT;
        else if(GWorld.getOneObjectAt(x, y, "Pig") != null) return MastermindWorld.PIG;
        else if(GWorld.getOneObjectAt(x, y, "YellowBalloon") != null) return MastermindWorld.YELLOW_BALLOON;
        else if(GWorld.getOneObjectAt(x, y, "OrangeBalloon") != null) return MastermindWorld.ORANGE_BALLOON;
        else if(GWorld.getOneObjectAt(x, y, "Block") != null) return MastermindWorld.BLOCK;
        else return MastermindWorld.NOTHING;
    }

    /*
     * Parameters:
     * x - the x coordinate
     * y - the y coordinate
     * 
     * Example:
     * Calling removeBaloons(2, 3) will remove any balloon at the position (2,3). 
     * It is safe to call the method even if the specified position has nothing in it - it just does nothing in that case.
     * 
     * It is able to remove mutliple balloons that exist at the same position at once.
     */
    public static void removeBalloons(int x, int y)
    {
        removeObjectsFromWorld(getAllObjectsAt(x, y, "Balloon"));
    }

    /*
     * Example:
     * Calling removeAllObjects() will remove all objects in the world. It should be used at the beginning of the initialize method.
     */
    private static void removeAllObjects()
    {   
        removeAllNonBlockObjects();
        GWorld.removeObjectsFromWorld(GWorld.getAllObjects("Block"));
    }

    /*
     * Example:
     * Calling removeAllNonBlockObjects() will remove all objects that are not blocks in the world. It should be used at the beginning of the loadGame method.
     */
    private static void removeAllNonBlockObjects()
    {   
        GWorld.removeObjectsFromWorld(GWorld.getAllObjects("Peg"));
        GWorld.removeObjectsFromWorld(GWorld.getAllObjects("SpecialCharacter"));
        GWorld.removeObjectsFromWorld(GWorld.getAllObjects("Balloon"));
        GWorld.removeObjectsFromWorld(GWorld.getAllObjects("Message"));
    }

    /*
     * It puts the given message at the top-right corner.
     */
    public static void showMessage(String message)
    {
        GWorld.removeObjectsFromWorld(GWorld.getAllObjects("Message"));
        Message m = new Message(message);
        GWorld.addOneObject(m, WORLD_WIDTH-2, 0);
    }
    
    /*
     * It might be used by yourself to place random pegs on the board for testing.
     */
    public static void test()
    {
        GWorld.removeObjectsFromWorld( GWorld.getAllObjects("Peg") );
        GWorld.removeObjectsFromWorld( GWorld.getAllObjects("Balloon") );
        Random randomNumberGenerator = new Random();
        char numberToPegCharacterMapping[] = {'w', 'd', 'e', 'p'};
        for(int i=1; i<=NUMBER_OF_PLAY_ROWS; i++)
        {
            MastermindWorld.addObject(numberToPegCharacterMapping[randomNumberGenerator.nextInt(4)], 0, i);
            MastermindWorld.addObject(numberToPegCharacterMapping[randomNumberGenerator.nextInt(4)], 1, i);
            MastermindWorld.addObject(numberToPegCharacterMapping[randomNumberGenerator.nextInt(4)], 2, i);
        }
    }
}
