import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class FriendJudge extends Judge
{
    public void judgeRow(int row)
	{
		System.out.println("FriendJudge looks at row " + row); //keep this line
        
		MastermindWorld.clearBalloons(row); //keep this line
		
		//part 2: complete the code below

		
	}
}
